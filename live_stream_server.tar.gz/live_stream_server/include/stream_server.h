#ifndef _STREAM_SERVER_H_
#define _STREAM_SERVER_H_

#include <stdint.h>

typedef enum _SERVER_MSG_TYPE
{
    SERVER_START_RECV_DATA_REQ  ,   /* start recv video & can data request*/
    SERVER_START_RECV_DATA_RESP ,   /* start recv video & can data response*/
    SERVER_STOP_RECV_DATA_REQ   ,   /* stop  recv video & can data request*/
    SERVER_STOP_RECV_DATA_RESP  ,   /* stop  recv video & can data response*/
} SERVER_MSG_TYPE;

#define MAX_SERVER_RECV_SIZE       (1*1024*1024)
#define MAX_SERVER_FRAME_SIZE      (4*1024*1024)
#define MAX_SERVER_CHANNEL_NUM     (32)
#define MAX_SERVER_RQ_PTR_SIZE     (sizeof(intptr_t))
#define MAX_SERVER_RQ_MEM_SIZE     (MAX_SERVER_FRAME_SIZE + sizeof(FRAME_HEADER_T))    // 一帧编码帧的大小(包括帧头)

typedef int (*frame_free_fnx)(intptr_t data);

typedef struct server_channel_cfg_st
{
    int32_t                        channel_index;
    int32_t                        server_port;
    int32_t                        rq_mem_size;
    int32_t                        rq_queue_num;
    frame_free_fnx                 frame_free_cb;
} server_channel_cfg_t, *lp_server_channel_cfg_t;

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif

void* stream_server_init(const char *ipaddr, lp_server_channel_cfg_t p_server_channel_cfg, int32_t server_channel_num, int32_t max_conn);

int stream_server_get_ipaddr(const char *if_name, char *address);

int stream_server_push(void* handle, int32_t index, char* data, int data_len, char* head, int head_len);

int stream_server_deinit(void* handle);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

#endif // end of _STREAM_SERVER_H_
