 /*****************************************************************************                                                                                   
 * Copyright (C) 2022 All rights reserved.
 * file : rtsp_server.h
 * auth : fancong
 * email: fancong20@163.com
 * data :
 * desp :
 * 
 ******************************************************************************/
#ifndef _RSTP_SERVER_H_
#define _RSTP_SERVER_H_

#include <stdint.h>

#define RTSP_FRAME_HEAD_CRC    (0x52545350) // RTSP

typedef enum rtsp_init_mode
{
    INIT_RING_BUFFER_MODE = 0,  // Ring buffer mode, used to send frame data to the buffer, does not involve rtsp server cfg
    INIT_RTSP_SERVER_MODE = 1,  // Rtsp server mode, used to get frame data from ring buffer and send it to rtsp server
} rtsp_init_mode_e;

typedef enum
{
    RTSP_SERVER_CODEC_ID_NONE = 0,
    RTSP_SERVER_CODEC_ID_VIDEO_H264 = 0x0001,    // codec_data is SPS + PPS frames
    RTSP_SERVER_CODEC_ID_VIDEO_H265,             // codec_data is VPS + SPS + PPS frames
    RTSP_SERVER_CODEC_ID_VIDEO_MPEG4,            // now not support
    RTSP_SERVER_CODEC_ID_AUDIO_G711A = 0x4001,   // codec_data is NULL
    RTSP_SERVER_CODEC_ID_AUDIO_G711U,            // codec_data is NULL
    RTSP_SERVER_CODEC_ID_AUDIO_G726,             // codec_data is bitrate (int)
    RTSP_SERVER_CODEC_ID_AUDIO_AAC,              // codec_data is audio specific config (2bytes). frame type is ADTS
} rtsp_codec_id_e;

typedef struct rtsp_server_st
{
    int     rtsp_port;     // rtsp server port
    char   *rtsp_path;     // rtsp server url path
    char   *rtsp_name;     // authorize name, NULL means no authorize
    char   *rtsp_passwd;   // authorize passwd, NULL means no authorize
} rtsp_server_t;

typedef struct rtsp_frame_st
{
    int32_t  magic;    // RTSP_FRAME_HEAD_CRC
    int32_t  codeid;   // rtsp codec id, see `rtsp_codec_id_e`
    uint64_t pts;      // showtime pts
    int32_t  length;   // frame data length
    uint8_t  data[0];  // var frame data
} rtsp_frame_t;

#ifdef __cplusplus
extern "C" {
#endif

void *rtsp_server_init(const char *path, int buffer_size, rtsp_init_mode_e init_mode, const rtsp_server_t *rtsps_cfg);

int32_t rtsp_server_deinit(void *handle, rtsp_init_mode_e init_mode);

int32_t rtsp_server_send_data_to_ring_buffer(void *handle, const rtsp_frame_t *rtsp_frame);

int32_t rtsp_server_send_data_to_server(void *handle);

#ifdef __cplusplus
}
#endif
#endif // end of _RSTP_SERVER_H_