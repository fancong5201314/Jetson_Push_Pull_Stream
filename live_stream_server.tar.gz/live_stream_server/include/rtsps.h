#ifndef __RTSP_SERVER_H__
#define __RTSP_SERVER_H__
/*
 * a simple RTSP server program
 * RTP over UDP/TCP H264/H265/G711a/G711u
 * note:
 * 1. Different ports, use different servers;
 * 2. Switching encoding parameters requires resetting the session;
 * 3. How to use:
   (1) Initialization
   for (int i=0; i<server_cnt; i++)
   {
       g_server_handle[i] = rtsp_new_server(port[i]);
       for (int j=0; j<session_cnt; j++)
       {
           snprintf(rtsp_path, sizeof(rtsp_path), "/live%d.sdp", j);
           g_session_handle[j] = rtsp_new_session(g_server_handle[i], rtsp_path, NULL, NULL);
       
           rtsp_set_video(g_session_handle[j], RTSP_CODEC_ID_VIDEO_H265, NULL, 0);
           rtsp_sync_video_ts(g_session_handle[j], rtsp_get_reltime(), rtsp_get_ntptime());
       }
   }

   (2) send 
   for (int i=0; i<server_cnt; i++)
   {
       pthread_mutex_lock(&server_lock[i]);
       for (int j=0; j<session_cnt; j++)
       {
           rtsp_tx_video(g_session_handle[j], video_data, video_data_size, video_pts);
           rtsp_tx_audio(g_session_handle[j], audio_data, audio_data_size, audio_pts);
           rtsp_do_event(g_server_handle[i]);
       }
       pthread_mutex_unlock(&server_lock[i]);
   }

   (3) DeInitialization
   for (int i=0; i<server_cnt; i++)
   {
       pthread_mutex_lock(&server_lock[i]);
       if (g_server_handle[i])
       {
           for (int j=0; j<session_cnt; j++)
           {
               rtsp_del_session(g_session_handle[j]);
               g_session_handle[j] = NULL;
           }
           rtsp_del_server(g_server_handle[i]);
           g_server_handle[i] = NULL;
       }
       pthread_mutex_unlock(&server_lock[i]);
       pthread_mutex_destroy(&server_lock[i]);
   }
*/

#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

enum rtsp_codec_id
{
    RTSP_CODEC_ID_NONE = 0,
    RTSP_CODEC_ID_VIDEO_H264 = 0x0001,    /* codec_data is SPS + PPS frames */
    RTSP_CODEC_ID_VIDEO_H265,             /* codec_data is VPS + SPS + PPS frames */
    RTSP_CODEC_ID_VIDEO_MPEG4,            /* now not support */
    RTSP_CODEC_ID_AUDIO_G711A = 0x4001,   /* codec_data is NULL */
    RTSP_CODEC_ID_AUDIO_G711U,            /* codec_data is NULL */
    RTSP_CODEC_ID_AUDIO_G726,             /* codec_data is bitrate (int) */
    RTSP_CODEC_ID_AUDIO_AAC,              /* codec_data is audio specific config (2bytes). frame type is ADTS */
};

#define RTSP_SERVER_DEFAULT_PORT       (554)
#define RTSP_SERVER_KEEP_IDLE_SEC      (60)
#define RTSP_SERVER_KEEP_INTERVAL_SEC  (3)
#define RTSP_SERVER_KEEP_COUNT         (5)
#define RTSP_SERVER_SEND_BUFFER_SIZE   (1<<23)  // 8MB ====> 64Mbps

typedef void *rtsp_server_handle;
typedef void *rtsp_session_handle;

rtsp_server_handle rtsp_new_server(int port);

int rtsp_do_event(rtsp_server_handle server);

// if the username and password are empty, authentication is disabled
rtsp_session_handle rtsp_new_session(rtsp_server_handle server, const char *path, const char *username, const char *password);

int rtsp_set_video(rtsp_session_handle session, int codec_id, const uint8_t *codec_data, int data_len);
int rtsp_set_audio(rtsp_session_handle session, int codec_id, const uint8_t *codec_data, int data_len);

int rtsp_tx_video(rtsp_session_handle session, const uint8_t *frame, int len, uint64_t ts);
int rtsp_tx_audio(rtsp_session_handle session, const uint8_t *frame, int len, uint64_t ts);
int rtsp_server_tx_video(rtsp_server_handle server, rtsp_session_handle session, const uint8_t *frame, int len, uint64_t ts);

void rtsp_del_session(rtsp_session_handle session);
void rtsp_del_server(rtsp_server_handle server);

uint64_t rtsp_get_reltime(void);
uint64_t rtsp_get_ntptime(void);

int rtsp_sync_video_ts(rtsp_session_handle session, uint64_t ts, uint64_t ntptime);
int rtsp_sync_audio_ts(rtsp_session_handle session, uint64_t ts, uint64_t ntptime);

#ifdef __cplusplus
}
#endif
#endif
