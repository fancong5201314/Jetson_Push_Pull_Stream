/*************************************************************************
 * Copyright (C) 2023 All rights reserved.
 *  文件名称：stream_log.h
 *  创 建 者：樊聪
 *  邮    箱：fancong20@163.com
 *  创建日期：2023年11月2日 星期四
 *  描    述：
 *  
 *  更新日志：
 *  
 *************************************************************************/  

#ifndef __STREAM_LOG_H__
#define __STREAM_LOG_H__

#include "stream_sdk.h"

#define DEVICE_IPADDR_SIZE       (16)
#define STREAM_LOG_DEF_PORT      (8000)
#define STREAM_LOG_MAX_SIZE      (4*1024*1024)

typedef struct VIDEO_INFO_ST
{
    VIDEO_ATTR_T             video_attr_user;   // user setting param
    VIDEO_ATTR_T             enc_attr_status;   // video attr status
    VIDEO_ATTR_T             yuv_attr_status;   // video attr status
    uint64_t                 enc_frame_num;     // encode frame num
    uint64_t                 yuv_frame_num;     // yuv frame num
} VIDEO_INFO_T, *LP_VIDEO_INFO_T;

typedef struct AUDIO_INFO_ST
{
    AUDIO_ATTR_T             audio_attr_user;
    AUDIO_ATTR_T             enc_attr_status;
    uint64_t                 enc_frame_num;
    int32_t                  audio_frame_num;
} AUDIO_INFO_T, *LP_AUDIO_INFO_T;

typedef struct STREAM_INFO_ST
{
    char                     ipaddr[DEVICE_IPADDR_SIZE];
    int32_t                  video_dev_num;
    int32_t                  audio_dev_num;
    VIDEO_INFO_T             video_info[SDK_MAX_VIDEO_NUM];
    AUDIO_INFO_T             audio_info[SDK_MAX_AUDIO_NUM];
} STREAM_INFO_T, *LP_STREAM_INFO_T;

#endif // end of __STREAM_LOG_H__