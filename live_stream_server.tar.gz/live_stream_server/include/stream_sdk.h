/*************************************************************************
 * Copyright (C) 2023 All rights reserved.
 *  文件名称：stream_sdk.h
 *  创 建 者：樊聪
 *  邮    箱：fancong20@163.com
 *  创建日期：2023年08月31日 星期四
 *  描    述：
 *  
 *  更新日志：
 *  
 *************************************************************************/  

#ifndef __STREAM_SDK_H__
#define __STREAM_SDK_H__

#include <stdint.h>

#ifdef __cplusplus
#if __cplusplus
extern "C"
{
#endif
#endif

//#define __CRC32__

#define SDK_MAX_VIDEO_NUM      (32)
#define SDK_MAX_AUDIO_NUM      (32)
#define FRAME_MAGIC_CODE       (0x48454144)     // HEAD
#define MAX_VIDEO_FRAME_SIZE   (10*1024*1024)   // Max frame store buffer size
#define MAX_AUDIO_SLICE_NUM    (1)
#define FRAME_HEAD_LENGTH      (48)

typedef enum 
{
    AUDIO_RATE_8000          = 8000,
    AUDIO_RATE_11025         = 11025,
    AUDIO_RATE_16000         = 16000,
    AUDIO_RATE_22050         = 22050,
    AUDIO_RATE_24000         = 32000,
    AUDIO_RATE_44100         = 44100,
    AUDIO_RATE_48000         = 48000,
    AUDIO_RATE_88200         = 88200,
    AUDIO_RATE_96000         = 96000,
} AUDIO_RATE_E;

typedef enum
{
    AUDIO_FMT_WAV            = 1,   // WAV : wavenc
    AUDIO_FMT_G711A          = 2,   // G.711 A : alawenc
    AUDIO_FMT_G711Mu         = 3,   // G.711 Mu : mulawenc
    AUDIO_FMT_ADPCM          = 4,   // ADPCM : adpcmenc
    AUDIO_FMT_G722           = 5,   // G.722 : avenc_g722
    AUDIO_FMT_G723           = 6,   // G.723 : avenc_g723_1
    AUDIO_FMT_G726           = 7,   // G.726 : avenc_g726
    AUDIO_FMT_G726_LE        = 8,   // G.726 LE : avenc_g726le
    AUDIO_FMT_AMR            = 9,   // AMR encoder format: voamrwbenc
    AUDIO_FMT_AAC            = 10,  // AAC : voaacenc / avenc_aac
    AUDIO_FMT_MP3            = 11,  // MP3: lamemp3enc
    AUDIO_FMT_FLAC           = 12,  // FLAC: flacenc
    AUDIO_FMT_BUTT,
} AUDIO_FORMAT_E;

typedef enum
{
    VIDEO_FMT_YUV            = 0,
    VIDEO_FMT_IFRAME         = 1,
    VIDEO_FMT_PFRAME         = 2,
    VIDEO_FMT_BFRAME         = 3,
} VIDEO_FORMAT_E;

typedef enum 
{
    LOAD_TYPE_YUV            = 0,
    LOAD_TYPE_H264           = 1,
    LOAD_TYPE_H265           = 2,
    LOAD_TYPE_MJPEG          = 3,
    LOAD_TYPE_AUDIO          = 4,
} SDK_LOAD_TYPE_E;

typedef enum
{
    ROT_NONE                 = 0,  // Identity (no rotation)
    ROT_CONTER_CLOCKWISE     = 1,  // Rotate counter-clockwise 90 degrees
    ROT_180                  = 2,  // rotate 180 degree
    ROT_CLOCKWISE            = 3,  // Rotate clockwise 90 degrees
    ROT_HFLIP                = 4,  // horizontal flip
    ROT_UP_RIGHT             = 5,  // Flip across upper right/lower left diagonal
    ROT_VFLIP                = 6,  // Flip vertically
    ROT_UP_LEFT              = 7,  // Flip across upper left/lower right diagonal
} ROTATE_DIR_E;

typedef struct AUDIO_ATTR_ST
{
    int32_t                  dev_num;
    AUDIO_RATE_E             rate;
    int32_t                  channel;
    AUDIO_FORMAT_E           format;
} AUDIO_ATTR_T, *LP_AUDIO_ATTR_T;

typedef struct UDP_SINK_ATTR_ST
{
    int8_t                   enable;         // enable udp sink
    char*                    host;           // udp host, NULL means brostcast addr 255.255.255.255
    int32_t                  port;           // udp port
} UDP_SINK_ATTR_T, *LP_UDP_SINK_ATTR_T;

typedef struct RECT_ST
{
    int32_t                  left;
    int32_t                  right;
    int32_t                  top;
    int32_t                  bottom;
} RECT_T, *LP_RECT_T;

typedef struct RECT_ATTR_ST
{
    int8_t                   enable;
    RECT_T                   rect;
} RECT_ATTR_T, *LP_RECT_ATTR_T;

typedef struct VIDEO_CONV_ATTR_ST
{
    RECT_ATTR_T              rect_attr;
    ROTATE_DIR_E             rotate;
} VIDEO_CONV_ATTR_T, *LP_VIDEO_CONV_ATTR_T;

typedef struct VENC_ATTR_ST
{
    SDK_LOAD_TYPE_E          type;
    int32_t                  fps;
    int32_t                  gop;
    int32_t                  bps;
    VIDEO_CONV_ATTR_T        enc_conv_attr;
} VENC_ATTR_ST;

typedef struct VIDEO_ATTR_ST
{
    int32_t                  dev_num;
    int32_t                  with_isp;
    int32_t                  width;
    int32_t                  height;
    VENC_ATTR_ST             venc_attr;
    VIDEO_CONV_ATTR_T        yuv_conv_attr;
    UDP_SINK_ATTR_T          udp_sink_attr;
} VIDEO_ATTR_T, *LP_VIDEO_ATTR_T;

typedef union 
{
    VIDEO_ATTR_T             video_attr;
    AUDIO_ATTR_T             audio_attr;
} STREAM_ATTR_U;

/* 帧头信息48字节 */
typedef struct FRAME_HEADER_ST
{
    uint32_t                 magic_code;      // 固定为 FRAME_MAGIC_CODE
    uint32_t                 frame_num;       // 媒体数据包的序号(音视频独立编号)
    uint8_t                  load_type;       // see: SDK_LOAD_TYPE_E
    uint8_t                  format;          // see: VIDEO_FORMAT_E or AUDIO_FORMAT_E
    uint64_t                 dts_ms;          // 时间戳(毫秒)
    uint64_t                 real_time_ms;    // 实时时间(毫秒)
    uint16_t                 width;           // 帧宽度
    uint16_t                 height;          // 帧高度
#ifdef __CRC32__
    uint8_t                  resolv[10];      // 保留
#else
    uint8_t                  resolv[14];      // 保留
#endif
    uint32_t                 frame_size;      // 帧数据长度
#ifdef __CRC32__
    uint32_t                 frame_crc32;     // 帧数据crc校验值
#endif
}__attribute__((packed)) FRAME_HEADER_T, *LP_FRAME_HEADER_T;

typedef int (*frame_recv_cb)(void* p_user_data, int32_t index, void* p_frame_head, const uint8_t* p_recv_buffer, int32_t recv_size);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif

void* stream_sdk_init(LP_VIDEO_ATTR_T p_video_attr, int32_t video_count, 
                      LP_AUDIO_ATTR_T p_audio_attr, int32_t audio_count, 
                      void* p_user_data, frame_recv_cb frame_recv_fnx);

int stream_sdk_deinit(void* p_handle);

#endif // end of __STREAM_SDK_H__

