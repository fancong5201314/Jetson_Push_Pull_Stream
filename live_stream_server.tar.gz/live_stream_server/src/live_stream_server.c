/*****************************************************************************
 * Copyright (C) 2024 All rights reserved.
 * 文件名称：live_stream_server.c
 * 创 建 者：樊聪
 * 邮    箱：fancong20@163.com
 * 创建日期：2024年04月01日 星期一
 * 描    述：
 *  
 * 更新日志：
 *  
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <unistd.h>
#include <libgen.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/stat.h>

#include "stream_sdk.h"
#include "stream_log.h"
#include "stream_server.h"
#include "rtsps.h"
#include "rtsp_server.h"

#define live_err(format, args...)  do{printf("\033[1;31m[LIVE_SS][%s-%d]\033[m" format, basename(__FILE__), __LINE__, ##args);}while(0)
#define live_dbg(format, args...)  do{printf("\033[1;32m[LIVE_SS][%s-%d]\033[m" format, basename(__FILE__), __LINE__, ##args);}while(0)
#define live_inf(format, args...)  do{printf("\033[1;35m[LIVE_SS]\033[m" format, ##args);}while(0)
#define live_sys(format, args...)  do{printf("\033[1;31m[LIVE_SS][%s-%d](%s) \033[m" format, basename(__FILE__), __LINE__, strerror(errno), ##args);}while(0)

typedef struct LIVE_SS_CTX_ST
{
    int   video_count;
    int   audio_count;
    void *sdk_handle;
    void *server_handle;
    void *rtsps_handle[SDK_MAX_VIDEO_NUM];
    void *rtsps_session[SDK_MAX_VIDEO_NUM];
    pthread_mutex_t stream_lock;
} LIVE_SS_CTX_T, *LP_LIVE_SS_CTX_T;

typedef struct RTSPS_CFG_ST
{
    int   rtsps_port;
    char *rtsps_path;
} RTSPS_CFG_T, *LP_RTSPS_CFG_T;

typedef struct LIVE_SS_CFG_ST
{

} LIVE_SS_CFG_T, *LP_LIVE_SS_CFG_T;

static LIVE_SS_CTX_T g_live_ss_ctx = {0};

static int read_stream_callback(void* p_user_data, int32_t index, void* p_frame_head, const uint8_t* p_recv_buffer, int32_t recv_size)
{
    if (!p_user_data || !p_frame_head || !p_recv_buffer)
    {
        live_err("p_user_data or p_frame_head or p_recv_buffer invaild.\n");
        return -1;
    }

    LP_LIVE_SS_CTX_T  live_ctx = (LP_LIVE_SS_CTX_T)p_user_data;
    LP_FRAME_HEADER_T frame_head = (LP_FRAME_HEADER_T)p_frame_head;

    pthread_mutex_lock(&live_ctx->stream_lock);

    if (LOAD_TYPE_AUDIO == frame_head->load_type)
    {
        for (int i=0; i<live_ctx->video_count; i++)
        {
            if (live_ctx->rtsps_handle[index] && live_ctx->rtsps_session[index])
            {
                //rtsp_tx_video(live_ctx->rtsps_session[i], p_recv_buffer, frame_head->frame_size, frame_head->dts_ms);
                rtsp_tx_audio(live_ctx->rtsps_session[i], p_recv_buffer, frame_head->frame_size, frame_head->dts_ms);
                rtsp_do_event(live_ctx->rtsps_handle[i]);
            }
        }

        if (live_ctx->server_handle)
        {
            int32_t ret = -1;
            char *p_frame_buffer = NULL;
            p_frame_buffer = (char *)calloc(1, sizeof(FRAME_HEADER_T)+frame_head->frame_size);
            if (!p_frame_buffer)
            {
                live_sys("Fail to calloc p_frame_buffer.\n");
                pthread_mutex_unlock(&live_ctx->stream_lock);
                return -1;
            }
            memcpy(p_frame_buffer, frame_head, sizeof(FRAME_HEADER_T));
            memcpy(p_frame_buffer+sizeof(FRAME_HEADER_T), p_recv_buffer, frame_head->frame_size);

            ret = stream_server_push(live_ctx->server_handle, 0,
                                     (char *)&p_frame_buffer, sizeof(intptr_t),
                                     (char *)p_frame_buffer, sizeof(FRAME_HEADER_T));
            if (ret)
            {
                live_err("Fail to called stream_server_push audio, ret %d.\n", ret);
                free(p_frame_buffer);
                p_frame_buffer = NULL;
                pthread_mutex_unlock(&live_ctx->stream_lock);
                return -1;
            }
        }
    }
    else
    {
        if (LOAD_TYPE_YUV == frame_head->load_type)
        {
        }
        else
        {
            if (live_ctx->rtsps_handle[index] && live_ctx->rtsps_session[index])
            {
                rtsp_tx_video(live_ctx->rtsps_session[index], p_recv_buffer, frame_head->frame_size, frame_head->dts_ms);
                //rtsp_tx_audio(live_ctx->rtsps_session[index], p_recv_buffer, frame_head->frame_size, frame_head->dts_ms);
                rtsp_do_event(live_ctx->rtsps_handle[index]);
            }

            if (live_ctx->server_handle)
            {
                int32_t ret = -1;
                char *p_frame_buffer = NULL;
                p_frame_buffer = (char *)calloc(1, sizeof(FRAME_HEADER_T)+frame_head->frame_size);
                if (!p_frame_buffer)
                {
                    live_sys("Fail to calloc p_frame_buffer.\n");
                    pthread_mutex_unlock(&live_ctx->stream_lock);
                    return -1;
                }
                memcpy(p_frame_buffer, frame_head, sizeof(FRAME_HEADER_T));
                memcpy(p_frame_buffer+sizeof(FRAME_HEADER_T), p_recv_buffer, frame_head->frame_size);
                ret = stream_server_push(live_ctx->server_handle, index,
                                         (char *)&p_frame_buffer, sizeof(intptr_t),
                                         (char *)p_frame_buffer, sizeof(FRAME_HEADER_T));
                if (ret)
                {
                    live_err("Fail to called stream_server_push, index %d, ret %d.\n", index, ret);
                    free(p_frame_buffer);
                    p_frame_buffer = NULL;
                    pthread_mutex_unlock(&live_ctx->stream_lock);
                    return -1;
                }
            }
        }
    }
    pthread_mutex_unlock(&live_ctx->stream_lock);

    return 0;
}

static int frame_free(intptr_t data)
{
    LP_FRAME_HEADER_T *p_frame_head = NULL;

    p_frame_head = (LP_FRAME_HEADER_T *) *((volatile intptr_t *)(data));
    if (p_frame_head)
    {
        free(p_frame_head);
        p_frame_head = NULL;
    }

    return 0;
}

static void sig_exit(int32_t signo)
{
    if (SIGINT == signo || SIGTERM == signo)
    {
        if (g_live_ss_ctx.sdk_handle)
        {
            stream_sdk_deinit(g_live_ss_ctx.sdk_handle);
            g_live_ss_ctx.sdk_handle = NULL;
        }

        if (g_live_ss_ctx.server_handle)
        {
            stream_server_deinit(g_live_ss_ctx.server_handle);
            g_live_ss_ctx.server_handle = NULL;
        }

        for (int i=0; i<g_live_ss_ctx.video_count; i++)
        {
            if (g_live_ss_ctx.rtsps_session[i])
            {
                rtsp_del_session(g_live_ss_ctx.rtsps_session[i]);
                g_live_ss_ctx.rtsps_session[i] = NULL;
            }
            if (g_live_ss_ctx.rtsps_handle[i])
            {
                rtsp_del_server(g_live_ss_ctx.rtsps_handle[i]);
                g_live_ss_ctx.rtsps_handle[i] = NULL;
            }
        }

        live_inf("program termination abnormally!\n");
    }
    exit(-1);
}

int main(int argc, const char *argv[])
{
    struct sigaction sa = {0};
    sa.sa_handler = sig_exit;
    sa.sa_flags = 0;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);

    // ignore PIPE Broken signal, avoid process exit.
    signal(SIGPIPE, SIG_IGN);

    VIDEO_ATTR_T video_attr[SDK_MAX_VIDEO_NUM] = 
    {
       //idx isp w      h       encode       fps gop    bps         rect     rotate       rect     rotate     udpsink
        {0, 1, 1920, 1080, {LOAD_TYPE_H265, 30, 30, 4096000, {{0, 0, 0, 0, 0}, 0}}, {{0, 0, 0, 0, 0}, 0}, {0, NULL, 5600}},
        {1, 1, 1920, 1080, {LOAD_TYPE_H265, 30, 30, 4096000, {{0, 0, 0, 0, 0}, 0}}, {{0, 0, 0, 0, 0}, 0}, {0, NULL, 5601}},
    };
    AUDIO_ATTR_T audio_attr[SDK_MAX_AUDIO_NUM] = 
    {
        {2, AUDIO_RATE_48000, 2, AUDIO_FMT_AAC},
    };

    pthread_mutex_init(&g_live_ss_ctx.stream_lock, NULL);

    g_live_ss_ctx.video_count = 2;
    g_live_ss_ctx.audio_count = 1;

    server_channel_cfg_t server_channel_cfg[] =
    {
        {0, 6060, 20*sizeof(intptr_t), 20, frame_free},
        {1, 6061, 20*sizeof(intptr_t), 20, frame_free},
    };
    
    RTSPS_CFG_T rtsps_cfg[] =
    {
        {8000, "/live.sdp"},
        {8001, "/live.sdp"},
    };

    // stream sdk
    g_live_ss_ctx.sdk_handle = stream_sdk_init(video_attr, g_live_ss_ctx.video_count, 
                                               audio_attr, g_live_ss_ctx.audio_count, 
                                               (void*)&g_live_ss_ctx, read_stream_callback);

    if (!g_live_ss_ctx.sdk_handle)
    {
        live_err("fail to called stream_sdk_init\n");
        return -1;
    }

    // live stream server
    char ipaddr[20] = {0};
    stream_server_get_ipaddr("eth0", ipaddr);
    g_live_ss_ctx.server_handle = stream_server_init(ipaddr, server_channel_cfg, sizeof(server_channel_cfg)/sizeof(server_channel_cfg[0]), 1000);
    if (!g_live_ss_ctx.server_handle)
    {
        live_err("fail to called stream_server_init\n");
        stream_sdk_deinit(g_live_ss_ctx.sdk_handle);
        return -1;
    }

    // rtsp server
    for (int32_t i=0; i<sizeof(rtsps_cfg)/sizeof(rtsps_cfg[0]); i++)
    {
        g_live_ss_ctx.rtsps_handle[i] = rtsp_new_server(rtsps_cfg[i].rtsps_port);
        // one rtsps only one session
        g_live_ss_ctx.rtsps_session[i] = rtsp_new_session(g_live_ss_ctx.rtsps_handle[i], rtsps_cfg[i].rtsps_path, NULL, NULL);    
        rtsp_set_video(g_live_ss_ctx.rtsps_session[i], 
                       LOAD_TYPE_H264==video_attr[i].venc_attr.type ? RTSP_CODEC_ID_VIDEO_H264 : RTSP_CODEC_ID_VIDEO_H265, 
                       NULL, 0);
        rtsp_sync_video_ts(g_live_ss_ctx.rtsps_session[i], rtsp_get_reltime(), rtsp_get_ntptime());
        rtsp_set_audio(g_live_ss_ctx.rtsps_session[i], 
                       AUDIO_FMT_G711A==audio_attr[0].format ? RTSP_CODEC_ID_AUDIO_G711A : AUDIO_FMT_G711Mu==audio_attr[0].format ? RTSP_CODEC_ID_AUDIO_G711U : RTSP_CODEC_ID_AUDIO_AAC, 
                       NULL, 0);
        rtsp_sync_audio_ts(g_live_ss_ctx.rtsps_session[i], rtsp_get_reltime(), rtsp_get_ntptime());
    }

    while (1)
    {
        sleep (1);
    }

    return 0;
}

