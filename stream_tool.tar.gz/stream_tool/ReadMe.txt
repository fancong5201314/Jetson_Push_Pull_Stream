/***********************************************************
 * Copyright (C) 2024 All rights reserved.
 * 文件名称：ReadMe.txt
 * 创 建 者：樊聪
 * 邮    箱：fancong20@163.com
 * 创建日期：2024年04月02日 星期二
 * 描    述：
 * 
 * 更新日志
 *  
 ***********************************************************/

d033cc0c61f1eb6ebcadfc84ece1d884  stream_tool_tegra
fb3d87bde0b1a38ffcb7535205ab4c64  stream_tool_x64_pc

运行:
./stream_tool_tegra    [目标板的IP地址]
./stream_tool_x64_pc   [目标板的IP地址]
